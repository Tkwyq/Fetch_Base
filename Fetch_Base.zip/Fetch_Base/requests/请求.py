import requests

data={'data':'dongman'}
response=requests.get('http://www.httpbin.org/get',params=data)
# print(response.headers)
# print(response.encoding)
# print(response.status_code)
# print(response.cookies)
print(response.text)
print(response.json())