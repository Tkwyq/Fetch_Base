import requests

# 会话维持， requests.session()，相当于在同一个浏览器请求

# 证书验证  verify=False 不进行证书验证，指定证书cert
response=requests.get('https://www.12306.cn',verify=False)
print(response.status_code)
# 代理ip
