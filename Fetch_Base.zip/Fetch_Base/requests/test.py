import os


os.remove('favicon.ico')