import requests
response=requests.get('https://github.com/favicon.ico')
print(type(response.text),type(response.content))
# print(response.content)
# print(response.text)
img=open('favicon.ico','wb')
img.write(response.content)
img.close()
