#-*- coding:utf-8 _*-  
""" 
file Name： Create_table
author:贾帅帅 
date: 2017/8/26  18:07 
Description :创建表
"""
import pymysql

db=pymysql.connect('localhost','root','root','TESTDB')
cursor=db.cursor()
cursor.execute('DROP TABLE IF EXISTS EMPLOYEE')
create_table='''CREATE TABLE EMPLOYEE (
         FIRST_NAME  CHAR(20) NOT NULL,
         LAST_NAME  CHAR(20),
         AGE INT,  
         SEX CHAR(1),
         INCOME FLOAT )'''
cursor.execute(create_table)
cursor.close()