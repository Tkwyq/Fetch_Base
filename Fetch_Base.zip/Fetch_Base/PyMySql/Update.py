#-*- coding:utf-8 _*-  
""" 
file Name： Update
author:贾帅帅 
date: 2017/8/26  20:28 
Description :更新
"""
import pymysql
db=pymysql.connect('localhost','root','root','TESTDB')
cursor=db.cursor()
sql = "UPDATE EMPLOYEE SET AGE = AGE + 1\
       WHERE SEX = '%c'" % ('M')
try:
    cursor.execute(sql)
    db.commit()
    print('更新成功 ')
except:
    db.rollback()

db.close()