#-*- coding:utf-8 _*-  
""" 
file Name： Insert
author:贾帅帅 
date: 2017/8/26  20:28 
Description :插入操作
"""
import pymysql
db=pymysql.connect('localhost','root','root','TESTDB')
cursor=db.cursor()
insert_sql="INSERT INTO EMPLOYEE(FIRST_NAME, \
          LAST_NAME, AGE, SEX, INCOME) \
          VALUES ('%s', '%s', '%d', '%c', '%d')" % \
            ('Mac', 'Mohan', 20, 'M', 2000)
try:
    cursor.execute(insert_sql)
    db.commit()
    print('插入成功 ')
except:
    db.rollback()

db.close()