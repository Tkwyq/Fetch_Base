#-*- coding:utf-8 _*-  
""" 
file Name： Connect_Redis
author:贾帅帅 
date: 2017/8/27  18:45 
Description :连接redis
"""
import redis

r=redis.Redis(host='localhost',port=6379,db=0)
r.set('test','hello word')
print(r.get('test'))