#-*- coding:utf-8 _*-  
""" 
file Name： 连接池
author:贾帅帅 
date: 2017/8/27  18:55 
Description :连接池
"""
# 　redis-py使用connection pool来管理对一个redis server的所有连接，\
# 避免每次建立、释放连接的开销。默认，每个Redis实例都会维护一个自己的连接池。
# 可以直接建立一个连接池，然后作为参数Redis，这样就可以实现多个Redis实例共享一个连接池。
import redis

pool = redis.ConnectionPool(host='localhost', port=6379)
r = redis.Redis(connection_pool=pool)
r.set('name', 'zhangsan')   #添加
print (r.get('name'))   #获取