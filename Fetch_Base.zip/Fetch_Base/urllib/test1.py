from urllib import request,parse

url='http://httpbin.org/post'
headers={
'User-Agent':'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.28 Safari/537.36'
}
dict = {
    'name': 'Germey'
}
data=parse.urlencode(dict).encode('utf-8')
re=request.Request(url=url,headers=headers,data=data)
resp=request.urlopen(re)
print(resp.read())
print(resp.status)