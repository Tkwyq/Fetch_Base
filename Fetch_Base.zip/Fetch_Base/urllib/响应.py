import urllib.request
import urllib.parse
# get请求
# response=urllib.request.urlopen('http://www.baidu.com')
# print(response.read().decode('utf-8'))

# post请求
data=urllib.parse.urlencode({'werd':'hello'}).encode('utf-8')
response=urllib.request.urlopen('http://httpbin.org/post',data=data)
print(response.read())
# 响应类型
print(type(response))
# 响应状态
print(response.status)
print(response.getheaders())

