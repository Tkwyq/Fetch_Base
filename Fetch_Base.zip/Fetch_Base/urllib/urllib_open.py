# import urllib.parse
# import urllib.request
from urllib import request, parse

data=parse.urlencode({'word': 'hello'}).encode('utf-8')
print(data)
response = request.urlopen('http://httpbin.org/post', data=data)
print(response.read())