from urllib.parse import urlparse
from urllib.parse import urlencode
result=urlparse('https://baike.baidu.com/item/%E6%AD%A3%E5%88%99%E8%A1%A8%E8%BE%BE%E5%BC%8F/1700215?fr=aladdin')
# print(type(result),result)
data={'num':8,'type':'math'}

print(urlencode(data))