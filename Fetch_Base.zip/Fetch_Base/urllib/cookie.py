#-*- coding:utf-8 _*-  
""" 
file Name： cookie
author:贾帅帅 
date: 2017/8/25  10:36 
Description :cookie的相关运用，存到本地，使用已存在的cookie等，
"""

# import http.cookiejar, urllib.request
# # cookie保存到内存
# cookie = http.cookiejar.CookieJar()
# handler = urllib.request.HTTPCookieProcessor(cookie)
# opener = urllib.request.build_opener(handler)
# response = opener.open('http://www.baidu.com')
# for item in cookie:
#     print(item.name+"="+item.value)
# 保存到本地
import http.cookiejar, urllib.request
filename = "cookie.txt"
cookie = http.cookiejar.MozillaCookieJar(filename)
handler = urllib.request.HTTPCookieProcessor(cookie)
opener = urllib.request.build_opener(handler)
response = opener.open('http://www.baidu.com')
cookie.save(ignore_discard=True, ignore_expires=True)