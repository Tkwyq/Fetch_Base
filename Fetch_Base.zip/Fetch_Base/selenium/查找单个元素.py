import selenium
from selenium import webdriver
# web.find_element(By.ID,'q')


web=webdriver.Chrome()
web.get('http://www.taobao.com')
id_q=web.find_element_by_id('q')
id_q_css=web.find_element_by_css_selector("#q")
print(id_q,id_q_css)
web.close()