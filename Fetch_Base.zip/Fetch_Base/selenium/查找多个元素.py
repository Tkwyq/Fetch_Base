from selenium import webdriver
import selenium
webdriver=webdriver.Chrome()
webdriver.get('http://www.zzti.edu.cn')
td=webdriver.find_elements_by_css_selector(".c67187")
print(td)
webdriver.close()