import selenium
from selenium import webdriver
import time

web=webdriver.Chrome()
web.get('https://www.taobao.com')
input_web=web.find_element_by_id('q')
input_web.send_keys('iPhone')
time.sleep(1)
input_web.clear()
input_web.send_keys('T恤')
button_web=web.find_element_by_css_selector('.btn-search')
button_web.click()