from selenium import webdriver

browser = webdriver.Chrome()
url = 'https://www.zhihu.com/explore'
browser.get(url)
input = browser.find_element_by_class_name('zu-top-add-question')
# 属性
print(input.get_attribute('class'))
# 文本值
print(input.text)
# 标签名
print(input.tag_name)
# 长度
print(input.size)
# 位置
print(input.location)